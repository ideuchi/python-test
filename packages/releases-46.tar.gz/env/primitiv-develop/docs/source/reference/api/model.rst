=====
Model
=====


.. doxygenclass:: primitiv::Model
  :members:
