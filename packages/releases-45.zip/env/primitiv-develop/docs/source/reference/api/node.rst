====
Node
====


.. doxygenclass:: primitiv::Node
  :members:
