========================
Default Device and Graph
========================

TBD.
