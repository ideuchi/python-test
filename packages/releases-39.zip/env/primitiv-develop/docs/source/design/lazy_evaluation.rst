===============
Lazy Evaluation
===============

TBD.
