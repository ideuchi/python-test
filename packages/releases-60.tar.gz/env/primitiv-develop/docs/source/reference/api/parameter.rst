=========
Parameter
=========


.. doxygenclass:: primitiv::Parameter
  :members:
