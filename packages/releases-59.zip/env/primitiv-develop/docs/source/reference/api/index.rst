======================
primitiv API Reference
======================


.. toctree::
  :caption: Contents:
  :titlesonly:

  devices
  functions
  graph
  initializers
  model
  node
  optimizers
  parameter
  shape
  tensor
