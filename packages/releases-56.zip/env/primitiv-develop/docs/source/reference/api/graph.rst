=====
Graph
=====


.. doxygenclass:: primitiv::Graph
  :members:
