=====
Shape
=====


.. doxygenclass:: primitiv::Shape
  :members:
