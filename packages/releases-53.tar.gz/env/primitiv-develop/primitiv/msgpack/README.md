Abstract
========

This directory includes an IOStream-like interface to read/write MessagePack
wire format.

Formal MessagePack specification can be found in:

[https://github.com/msgpack/msgpack](https://github.com/msgpack/msgpack)
