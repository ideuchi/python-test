======
Tensor
======


.. doxygenclass:: primitiv::Tensor
  :members:
