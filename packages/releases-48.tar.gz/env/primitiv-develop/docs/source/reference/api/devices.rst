=======
Devices
=======


Base Class
----------


.. doxygenclass:: primitiv::Device
  :members:


Inherited Classes
-----------------


.. doxygenclass:: primitiv::devices::Naive
  :members:

.. doxygenclass:: primitiv::devices::Eigen
  :members:

.. doxygenclass:: primitiv::devices::CUDA
  :members:

.. doxygenclass:: primitiv::devices::OpenCL
  :members:
