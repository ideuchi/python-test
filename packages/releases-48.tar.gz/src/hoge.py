# coding utf-8

class Hoge:

	def index(self):
		return True

