#ifndef PRIMITIV_CORE_FUNCTIONS_H_
#define PRIMITIV_CORE_FUNCTIONS_H_

#include <primitiv/core/arithmetic.h>
#include <primitiv/core/basic_functions.h>

// TODO(odashi): This include is deprecated; will be removed in the future.
#include <primitiv/contrib/functions.h>

#endif  // PRIMITIV_CORE_FUNCTIONS_H_
