======================
primitiv C++ Tutorials
======================


This section describes tutorials to learn how to use primitiv in your C++ code..


.. toctree::
  :caption: Contents:
  :titlesonly:

  xor
