=================================
Operation Rules with Minibatching
=================================

TBD.
