#!/bin/bash

git clone https://github.com/odashi/small_parallel_enja data
rm -rf data/.git
