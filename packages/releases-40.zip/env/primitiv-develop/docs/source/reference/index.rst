==================
primitiv Reference
==================


This section contains low-level information about primitiv.


.. toctree::
  :caption: Contents:
  :titlesonly:

  api/index
  build_options
  file_format
